const AWS = require('aws-sdk');
const mysql = require('mysql2/promise');

// Initialize AWS services
const ses = new AWS.SES({ region: 'us-east-1' });

exports.handler = async (event) => {
    console.log('Received event:', JSON.stringify(event, null, 2));
    
    // Handle CORS preflight requests
    if (event.httpMethod === 'OPTIONS') {
        return {
            statusCode: 200,
            headers: {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Methods': 'POST, OPTIONS',
                'Access-Control-Allow-Headers': 'Content-Type'
            },
            body: JSON.stringify({ message: 'CORS preflight' })
        };
    }
    
    try {
        // Parse the request body
        let body;
        try {
            body = JSON.parse(event.body);
        } catch (parseError) {
            console.error('Error parsing JSON:', parseError);
            return {
                statusCode: 400,
                headers: { 'Access-Control-Allow-Origin': '*' },
                body: JSON.stringify({ error: 'Invalid JSON format' })
            };
        }
        
        const { name, email, phone, message } = body;
        
        // Validate required fields
        if (!name || !email || !message) {
            return {
                statusCode: 400,
                headers: { 'Access-Control-Allow-Origin': '*' },
                body: JSON.stringify({ 
                    error: 'Name, email, and message are required fields' 
                })
            };
        }
        
        // Validate email format
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email)) {
            return {
                statusCode: 400,
                headers: { 'Access-Control-Allow-Origin': '*' },
                body: JSON.stringify({ error: 'Invalid email format' })
            };
        }
        
        // Connect to MySQL database
        let connection;
        try {
            connection = await mysql.createConnection({
                host: process.env.DB_HOST,
                user: process.env.DB_USER,
                password: process.env.DB_PASSWORD,
                database: process.env.DB_NAME,
                ssl: { rejectUnauthorized: false } // Required for RDS
            });
            console.log('Successfully connected to database');
        } catch (dbError) {
            console.error('Database connection error:', dbError);
            return {
                statusCode: 500,
                headers: { 'Access-Control-Allow-Origin': '*' },
                body: JSON.stringify({ 
                    error: 'Database connection failed',
                    details: dbError.message 
                })
            };
        }
        
        // Save to database
        try {
            const [result] = await connection.execute(
                'INSERT INTO contacts (name, email, phone, message) VALUES (?, ?, ?, ?)',
                [name, email, phone || null, message]
            );
            console.log('Database insert result:', result);
        } catch (insertError) {
            console.error('Database insert error:', insertError);
            await connection.end();
            return {
                statusCode: 500,
                headers: { 'Access-Control-Allow-Origin': '*' },
                body: JSON.stringify({ 
                    error: 'Failed to save contact information',
                    details: insertError.message 
                })
            };
        }
        
        // Send email notification
        try {
            const emailParams = {
                Destination: {
                    ToAddresses: [process.env.BUSINESS_EMAIL || 'smtaxservicesinc@gmail.com']
                },
                Message: {
                    Body: {
                        Text: {
                            Data: `
New Contact Form Submission:

Name: ${name}
Email: ${email}
Phone: ${phone || 'Not provided'}
Message: ${message}

Submitted at: ${new Date().toLocaleString()}
                            `.trim()
                        },
                        Html: {
                            Data: `
<!DOCTYPE html>
<html>
<head>
    <style>
        body { font-family: Arial, sans-serif; }
        .container { max-width: 600px; margin: 0 auto; padding: 20px; }
        .header { background: #2E86AB; color: white; padding: 15px; text-align: center; }
        .content { background: #f9f9f9; padding: 20px; }
        .field { margin-bottom: 10px; }
        .label { font-weight: bold; color: #333; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h2>New Contact Form Submission</h2>
        </div>
        <div class="content">
            <div class="field">
                <span class="label">Name:</span> ${name}
            </div>
            <div class="field">
                <span class="label">Email:</span> ${email}
            </div>
            <div class="field">
                <span class="label">Phone:</span> ${phone || 'Not provided'}
            </div>
            <div class="field">
                <span class="label">Message:</span><br>
                ${message.replace(/\n/g, '<br>')}
            </div>
            <div class="field">
                <span class="label">Submitted:</span> ${new Date().toLocaleString()}
            </div>
        </div>
    </div>
</body>
</html>
                            `.trim()
                        }
                    },
                    Subject: {
                        Data: `New Contact Form Submission from ${name}`
                    }
                },
                Source: process.env.SES_SENDER || 'notifications@smtaxservices.com'
            };
            
            const emailResult = await ses.sendEmail(emailParams).promise();
            console.log('Email sent successfully:', emailResult);
            
        } catch (emailError) {
            console.error('Email sending error:', emailError);
            // Don't fail the entire request if email fails, just log it
        }
        
        // Close database connection
        await connection.end();
        
        // Return success response
        return {
            statusCode: 200,
            headers: {
                'Access-Control-Allow-Origin': '*',
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                message: 'Contact form submitted successfully',
                success: true
            })
        };
        
    } catch (error) {
        console.error('Unexpected error:', error);
        return {
            statusCode: 500,
            headers: { 'Access-Control-Allow-Origin': '*' },
            body: JSON.stringify({ 
                error: 'Internal server error',
                details: error.message 
            })
        };
    }
};